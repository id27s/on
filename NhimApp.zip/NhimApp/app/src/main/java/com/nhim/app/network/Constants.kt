package com.nhim.app.network

object Constants {
    // TODO: đổi lại nếu path api khác
    const val BASE_URL = "http://nhim.rf.gd/api/"
}
