package com.nhim.app.util

import java.math.BigInteger
import java.security.MessageDigest

object Md5Util {
    fun md5(input: String): String {
        val digest = MessageDigest.getInstance("MD5")
        val bytes = digest.digest(input.toByteArray())
        val bigInt = BigInteger(1, bytes)
        var hash = bigInt.toString(16)
        while (hash.length < 32) {
            hash = "0$hash"
        }
        return hash
    }
}
