package com.nhim.app.ui.posts

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.nhim.app.databinding.FragmentPostsBinding
import com.nhim.app.network.ApiClient
import kotlinx.coroutines.launch

class PostsFragment : Fragment() {

    private var _binding: FragmentPostsBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: PostAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPostsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = PostAdapter(emptyList())
        binding.recyclerPosts.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerPosts.adapter = adapter

        binding.swipeRefresh.setOnRefreshListener { loadPosts() }

        binding.fabAddPost.setOnClickListener {
            startActivity(Intent(requireContext(), CreatePostActivity::class.java))
        }

        loadPosts()
    }

    override fun onResume() {
        super.onResume()
        loadPosts() // tự load lại khi quay về từ màn hình đăng bài
    }

    private fun loadPosts() {
        binding.swipeRefresh.isRefreshing = true
        lifecycleScope.launch {
            try {
                val api = ApiClient.getInstance(requireContext())
                val res = api.getPosts()
                if (res.isSuccessful && res.body() != null) {
                    adapter.updateData(res.body()!!)
                } else {
                    Toast.makeText(requireContext(), "Không tải được bài viết", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Lỗi kết nối: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
