package com.nhim.app.network

import android.content.Context
import android.content.SharedPreferences
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl

/**
 * CookieJar don gian, luu cookie (vi du PHPSESSID) vao SharedPreferences
 * de session dang nhap duoc giu lai giua cac request va giua cac lan mo app.
 */
class PersistentCookieJar(context: Context) : CookieJar {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("cookie_prefs", Context.MODE_PRIVATE)

    override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
        val editor = prefs.edit()
        for (cookie in cookies) {
            editor.putString(cookie.name, cookie.value)
        }
        editor.apply()
    }

    override fun loadForRequest(url: HttpUrl): List<Cookie> {
        val cookies = mutableListOf<Cookie>()
        for ((name, value) in prefs.all) {
            if (value is String) {
                val cookie = Cookie.Builder()
                    .name(name)
                    .value(value)
                    .domain(url.host)
                    .build()
                cookies.add(cookie)
            }
        }
        return cookies
    }

    fun clear() {
        prefs.edit().clear().apply()
    }
}
