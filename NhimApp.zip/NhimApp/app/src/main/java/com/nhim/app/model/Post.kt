package com.nhim.app.model

import com.google.gson.annotations.SerializedName

data class Post(
    @SerializedName("id") val id: Int,
    @SerializedName("title") val title: String,       // TODO: đổi "title" nếu API thực trả key khác (bạn gõ "titlte")
    @SerializedName("content") val content: String,
    @SerializedName("like") val likes: List<String>?,  // danh sách username đã like
    @SerializedName("user_post") val userPost: String,
    @SerializedName("cat") val cat: Int,
    @SerializedName("time") val time: Long              // unix timestamp
)
