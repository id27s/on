package com.nhim.app.ui.posts

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nhim.app.databinding.ActivityCreatePostBinding
import com.nhim.app.network.ApiClient
import com.nhim.app.util.SessionManager
import kotlinx.coroutines.launch

class CreatePostActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCreatePostBinding
    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreatePostBinding.inflate(layoutInflater)
        setContentView(binding.root)

        session = SessionManager(this)
        binding.btnSubmit.setOnClickListener { submitPost() }
    }

    private fun submitPost() {
        val title = binding.edtTitle.text.toString().trim()
        val content = binding.edtContent.text.toString().trim()
        val catStr = binding.edtCat.text.toString().trim()

        if (title.isEmpty() || content.isEmpty()) {
            Toast.makeText(this, "Nhập tiêu đề và nội dung", Toast.LENGTH_SHORT).show()
            return
        }
        val cat = catStr.toIntOrNull() ?: 0

        val user = session.getUsername()
        val pass = session.getPasswordMd5()
        if (user == null || pass == null) {
            Toast.makeText(this, "Bạn cần đăng nhập lại", Toast.LENGTH_SHORT).show()
            return
        }

        setLoading(true)
        lifecycleScope.launch {
            try {
                val api = ApiClient.getInstance(this@CreatePostActivity)
                val res = api.createPost(user, pass, title, content, cat)
                if (res.isSuccessful && res.body()?.isSuccess() == true) {
                    Toast.makeText(this@CreatePostActivity, "Đăng bài thành công", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    val msg = res.body()?.message ?: "Đăng bài thất bại"
                    Toast.makeText(this@CreatePostActivity, msg, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@CreatePostActivity, "Lỗi kết nối: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                setLoading(false)
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        binding.btnSubmit.isEnabled = !loading
    }
}
