package com.nhim.app.model

import com.google.gson.annotations.SerializedName

data class ChatMessage(
    @SerializedName("id") val id: Int,
    @SerializedName("user") val user: String,
    @SerializedName("content") val content: String,
    @SerializedName("time") val time: Long
)
