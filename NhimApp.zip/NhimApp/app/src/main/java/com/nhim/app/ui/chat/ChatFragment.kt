package com.nhim.app.ui.chat

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.nhim.app.databinding.FragmentChatBinding
import com.nhim.app.network.ApiClient
import com.nhim.app.util.SessionManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class ChatFragment : Fragment() {

    private var _binding: FragmentChatBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: MessageAdapter
    private lateinit var session: SessionManager

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentChatBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        session = SessionManager(requireContext())

        adapter = MessageAdapter(emptyList())
        binding.recyclerMessages.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerMessages.adapter = adapter

        binding.btnSend.setOnClickListener { sendMessage() }

        // Tu dong lam moi tin nhan moi 5 giay khi Fragment con hien thi
        viewLifecycleOwner.lifecycleScope.launch {
            while (isActive) {
                loadMessages()
                delay(5000)
            }
        }
    }

    private fun sendMessage() {
        val content = binding.edtMessage.text.toString().trim()
        if (content.isEmpty()) return

        val user = session.getUsername()
        val pass = session.getPasswordMd5()
        if (user == null || pass == null) {
            Toast.makeText(requireContext(), "Bạn cần đăng nhập lại", Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch {
            try {
                val api = ApiClient.getInstance(requireContext())
                val res = api.sendMessage(user, pass, content)
                if (res.isSuccessful && res.body()?.isSuccess() == true) {
                    binding.edtMessage.setText("")
                    loadMessages()
                } else {
                    Toast.makeText(requireContext(), res.body()?.message ?: "Gửi thất bại", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Lỗi kết nối: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private suspend fun loadMessages() {
        try {
            val api = ApiClient.getInstance(requireContext())
            val res = api.getMessages()
            if (res.isSuccessful && res.body() != null) {
                adapter.updateData(res.body()!!)
                binding.recyclerMessages.scrollToPosition(adapter.itemCount - 1)
            }
        } catch (e: Exception) {
            // lang le bo qua loi polling de khong lam phien nguoi dung
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
