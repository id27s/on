package com.nhim.app.ui.login

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nhim.app.databinding.ActivityLoginBinding
import com.nhim.app.network.ApiClient
import com.nhim.app.ui.main.MainActivity
import com.nhim.app.ui.register.RegisterActivity
import com.nhim.app.util.Md5Util
import com.nhim.app.util.SessionManager
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        session = SessionManager(this)

        // Nếu đã đăng nhập trước đó -> vào thẳng MainActivity
        if (session.isLoggedIn()) {
            goToMain()
            return
        }

        binding.btnLogin.setOnClickListener { doLogin() }
        binding.tvGoRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }

    private fun doLogin() {
        val user = binding.edtUser.text.toString().trim()
        val pass = binding.edtPass.text.toString()

        if (user.isEmpty() || pass.isEmpty()) {
            Toast.makeText(this, "Nhập đầy đủ tên đăng nhập và mật khẩu", Toast.LENGTH_SHORT).show()
            return
        }

        val passMd5 = Md5Util.md5(pass)
        setLoading(true)

        lifecycleScope.launch {
            try {
                val api = ApiClient.getInstance(this@LoginActivity)
                val res = api.login(user, passMd5)

                if (res.isSuccessful && res.body()?.isSuccess() == true) {
                    session.saveSession(user, passMd5)
                    goToMain()
                } else {
                    val msg = res.body()?.message ?: "Đăng nhập thất bại"
                    Toast.makeText(this@LoginActivity, msg, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@LoginActivity, "Lỗi kết nối: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                setLoading(false)
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        binding.btnLogin.isEnabled = !loading
    }

    private fun goToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
