package com.nhim.app.model

import com.google.gson.annotations.SerializedName

data class GenericResponse(
    @SerializedName("status") val status: String,   // "success" hoặc "error"
    @SerializedName("message") val message: String? = null
) {
    fun isSuccess(): Boolean = status.equals("success", ignoreCase = true)
}
