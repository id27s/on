package com.nhim.app.util

import android.content.Context
import android.content.SharedPreferences

/**
 * Luu thong tin dang nhap (username + pass da MD5) de:
 * 1) Biet user da dang nhap chua khi mo lai app.
 * 2) Gui lai user/pass cho cac API can xac thuc (createPost, sendMessage...)
 *    vi API hien tai doi hoi user/pass o moi request, khong chi dua vao session cookie.
 */
class SessionManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("session_prefs", Context.MODE_PRIVATE)

    fun saveSession(username: String, passwordMd5: String) {
        prefs.edit()
            .putString(KEY_USER, username)
            .putString(KEY_PASS, passwordMd5)
            .putBoolean(KEY_LOGGED_IN, true)
            .apply()
    }

    fun isLoggedIn(): Boolean = prefs.getBoolean(KEY_LOGGED_IN, false)

    fun getUsername(): String? = prefs.getString(KEY_USER, null)

    fun getPasswordMd5(): String? = prefs.getString(KEY_PASS, null)

    fun logout() {
        prefs.edit().clear().apply()
    }

    companion object {
        private const val KEY_USER = "user"
        private const val KEY_PASS = "pass"
        private const val KEY_LOGGED_IN = "logged_in"
    }
}
