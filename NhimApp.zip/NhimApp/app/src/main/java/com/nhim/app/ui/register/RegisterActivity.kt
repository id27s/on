package com.nhim.app.ui.register

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nhim.app.databinding.ActivityRegisterBinding
import com.nhim.app.network.ApiClient
import com.nhim.app.util.Md5Util
import kotlinx.coroutines.launch

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnRegister.setOnClickListener { doRegister() }
    }

    private fun doRegister() {
        val user = binding.edtUser.text.toString().trim()
        val pass = binding.edtPass.text.toString()
        val passConfirm = binding.edtPassConfirm.text.toString()

        if (user.isEmpty() || pass.isEmpty()) {
            Toast.makeText(this, "Nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show()
            return
        }
        if (pass != passConfirm) {
            Toast.makeText(this, "Mật khẩu nhập lại không khớp", Toast.LENGTH_SHORT).show()
            return
        }

        val passMd5 = Md5Util.md5(pass)
        setLoading(true)

        lifecycleScope.launch {
            try {
                val api = ApiClient.getInstance(this@RegisterActivity)
                val res = api.register(user, passMd5)

                if (res.isSuccessful && res.body()?.isSuccess() == true) {
                    Toast.makeText(this@RegisterActivity, "Đăng ký thành công, hãy đăng nhập", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    val msg = res.body()?.message ?: "Đăng ký thất bại"
                    Toast.makeText(this@RegisterActivity, msg, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@RegisterActivity, "Lỗi kết nối: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                setLoading(false)
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        binding.btnRegister.isEnabled = !loading
    }
}
