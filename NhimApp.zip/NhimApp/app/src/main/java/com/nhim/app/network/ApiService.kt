package com.nhim.app.network

import com.nhim.app.model.ChatMessage
import com.nhim.app.model.GenericResponse
import com.nhim.app.model.Post
import retrofit2.Response
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.POST

interface ApiService {

    // ---------- AUTH ----------

    @FormUrlEncoded
    @POST("login.php")
    suspend fun login(
        @Field("user") user: String,
        @Field("pass") passMd5: String
    ): Response<GenericResponse>

    @FormUrlEncoded
    @POST("register.php")
    suspend fun register(
        @Field("user") user: String,
        @Field("pass") passMd5: String
        // TODO: thêm field khác nếu register.php cần (email, v.v.)
    ): Response<GenericResponse>

    // ---------- POSTS ----------

    @GET("get_posts.php")
    suspend fun getPosts(): Response<List<Post>>

    // TODO: đổi tên "post.php" cho đúng file thật của bạn (đăng bài mới)
    @FormUrlEncoded
    @POST("post.php")
    suspend fun createPost(
        @Field("user") user: String,
        @Field("pass") passMd5: String,
        @Field("title") title: String,
        @Field("content") content: String,
        @Field("cat") cat: Int
    ): Response<GenericResponse>

    // ---------- CHAT ----------

    // TODO: đổi tên "get_messenge.php" nếu file thật khác tên
    @GET("get_messenge.php")
    suspend fun getMessages(): Response<List<ChatMessage>>

    // TODO: đổi tên "post_chat.php" cho đúng file thật gửi tin nhắn
    @FormUrlEncoded
    @POST("post_chat.php")
    suspend fun sendMessage(
        @Field("user") user: String,
        @Field("pass") passMd5: String,
        @Field("content") content: String
    ): Response<GenericResponse>
}
