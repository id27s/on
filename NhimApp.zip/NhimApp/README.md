# Nhim App - Android (Kotlin)

App Android kết nối tới API PHP tại `http://nhim.rf.gd/api/`:
- Đăng nhập / Đăng ký
- Xem danh sách bài viết (get_posts.php)
- Đăng bài mới
- Chat (gửi / nhận tin nhắn)

## ⚠️ Việc bạn CẦN sửa lại trước khi build (rất quan trọng)

Mình chưa biết chính xác tên file PHP và tên field thật của bạn cho: đăng bài,
gửi chat, nhận chat. Mở file:

`app/src/main/java/com/nhim/app/network/ApiService.kt`

và sửa các dòng có đánh dấu `// TODO:` cho khớp với tên file PHP thật
(`post.php`, `post_chat.php`, `get_messenge.php`...) và tên field (`user`,
`pass`, `title`, `content`, `cat`...).

Nếu response JSON thật của bạn có field khác tên, sửa trong:
`app/src/main/java/com/nhim/app/model/Post.kt`
`app/src/main/java/com/nhim/app/model/ChatMessage.kt`
`app/src/main/java/com/nhim/app/model/GenericResponse.kt`

## Build ra file APK bằng điện thoại (không cần máy tính / Android Studio)

Dùng GitHub Actions — máy chủ của GitHub sẽ build APK giúp bạn, bạn chỉ cần
trình duyệt điện thoại.

**Bước 1: Tạo tài khoản GitHub** (nếu chưa có) tại github.com — miễn phí.

**Bước 2: Tạo repository mới**
- Vào github.com → nhấn nút "+" → "New repository"
- Đặt tên (ví dụ `nhim-app`) → chọn Public hoặc Private → Create repository

**Bước 3: Upload toàn bộ code**
- Trong repo vừa tạo, chọn "Add file" → "Upload files"
- Giải nén file zip mình gửi, rồi kéo/chọn **toàn bộ file và thư mục bên
  trong** (bao gồm cả thư mục `.github`) vào khung upload
  (trình duyệt điện thoại vẫn upload được, chỉ cần chọn hết file)
- Nhấn "Commit changes"

**Bước 4: Chờ build tự động**
- Vào tab "Actions" ở trên cùng repo
- Sẽ thấy 1 lượt chạy "Build APK" đang chạy (mất khoảng 3-5 phút)
- Nếu có lỗi (dấu ❌ đỏ), bấm vào xem log lỗi để biết cần sửa gì

**Bước 5: Tải file APK về**
- Khi chạy xong (dấu ✅ xanh), bấm vào lượt chạy đó
- Kéo xuống mục "Artifacts", tải file `nhim-app-debug-apk.zip`
- Giải nén ra sẽ thấy `app-debug.apk`

**Bước 6: Cài lên điện thoại**
- Copy file `.apk` vào điện thoại Android (hoặc tải trực tiếp bằng điện thoại)
- Vào Settings cho phép "Install unknown apps" cho ứng dụng bạn dùng để mở file
- Bấm vào file `.apk` để cài đặt

## Cấu trúc code

- `network/` — Retrofit, OkHttp, cookie session, danh sách API (ApiService.kt)
- `model/` — các data class khớp JSON từ server
- `util/` — MD5, lưu session đăng nhập
- `ui/login`, `ui/register` — màn hình đăng nhập / đăng ký
- `ui/main` — màn hình chính (bottom nav: Bài viết / Chat)
- `ui/posts` — danh sách bài viết + đăng bài mới
- `ui/chat` — chat (tự làm mới mỗi 5 giây)
